import { ProjectCard, Project } from './ProjectCard';

export function Projects() {
  const projects: Project[] = [
    {
      title: 'Social Media Analytics Dashboard',
      description: 'Built a comprehensive dashboard to track engagement metrics across multiple social media platforms, helping brands optimize their content strategy.',
      techStack: ['React', 'TypeScript', 'Chart.js', 'API Integration'],
      demoLink: 'https://example.com/demo1',
      thumbnail: 'https://images.unsplash.com/photo-1759393852314-59dc00faeed3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2NpYWwlMjBtZWRpYSUyMGNvbnRlbnQlMjBjcmVhdGlvbnxlbnwxfHx8fDE3NjkxMTY0MjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      title: 'Content Scheduler App',
      description: 'Developed a web application for scheduling and automating social media posts with AI-powered caption suggestions and optimal posting time recommendations.',
      techStack: ['Next.js', 'Node.js', 'MongoDB', 'OpenAI API'],
      demoLink: 'https://example.com/demo2',
      thumbnail: 'https://images.unsplash.com/photo-1643116774075-acc00caa9a7b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWIlMjBkZXZlbG9wbWVudCUyMGNvZGV8ZW58MXx8fHwxNzY5MjAxOTY3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      title: 'Brand Identity Mobile App',
      description: 'Created a mobile-first web app for small businesses to maintain consistent brand voice and visual identity across all social platforms.',
      techStack: ['React Native', 'Firebase', 'Tailwind CSS'],
      demoLink: 'https://example.com/demo3',
      thumbnail: 'https://images.unsplash.com/photo-1609921212029-bb5a28e60960?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBkZXNpZ258ZW58MXx8fHwxNzY5MTIzMjQ2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
    },
    {
      title: 'Community Engagement Platform',
      description: 'Built an interactive platform for managing community interactions, tracking sentiment analysis, and fostering authentic conversations with followers.',
      techStack: ['Vue.js', 'Python', 'Natural Language Processing', 'PostgreSQL'],
      demoLink: 'https://example.com/demo4'
    },
    {
      title: 'Influencer Collaboration Tool',
      description: 'Designed a streamlined tool for coordinating influencer partnerships, tracking deliverables, and measuring campaign ROI.',
      techStack: ['React', 'Express', 'MySQL', 'Stripe API'],
      demoLink: 'https://example.com/demo5'
    },
    {
      title: 'Trend Discovery Engine',
      description: 'Developed an AI-powered tool that identifies emerging trends and viral content opportunities across social media platforms in real-time.',
      techStack: ['Python', 'Machine Learning', 'React', 'Redis'],
      demoLink: 'https://example.com/demo6'
    }
  ];

  return (
    <section id="projects" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="container mx-auto">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl sm:text-4xl mb-4">My Projects</h2>
          <p className="text-lg text-muted-foreground">
            A collection of projects that showcase my ability to blend technical skills with 
            creative problem-solving for social media and digital communication.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <ProjectCard key={index} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
