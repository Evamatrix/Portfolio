
  # Portfolio Website for Graduate

  This is a code bundle for Portfolio Website for Graduate. The original project is available at https://www.figma.com/design/QO17m1zsP55765QFPjkG8I/Portfolio-Website-for-Graduate.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  